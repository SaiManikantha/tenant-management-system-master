# License MIT (https://opensource.org/licenses/MIT).

from . import ir_actions
from . import ir_translation
from . import publisher_warranty_contract
from . import ir_config_parameter
from . import ir_ui_view
from . import mail_message
from . import mail_channel
from . import res_users
