import re
import json
import base64
import random
import logging
import requests
import werkzeug
import werkzeug.utils
from odoo import http
from wsgiref import headers
from odoo.http import request
from collections import OrderedDict
from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError

_logger = logging.getLogger(__name__)


class PappayaRegistration(http.Controller):

    @http.route('/registration', website=True, type='http', auth='none')
    def registration_portal(self, **kw):
        return request.render('pappayalite_backend.pappaya_registration_page', {
            'recaptcha_site_key': request.env['ir.config_parameter'].sudo().get_param('recaptcha_site_key')
        })

    @http.route('/registration_save', methods=['post'], type='http', auth='public', csrf=False)
    def registration_save(self, **post):
        # Validate required fields
        required_fields = ['first_name', 'last_name', 'email', 'phone', 'password', 'school_name', 'street_number', 'route', 'locality', 'administrative_area_level_1', 'postal_code', 'country']
        error_fields = {}
        for field in required_fields:
            if (post.get(field) == ''):
                error_fields[field] = 'This is a required field'

        # Check if email exists
        is_already_registered = (request.env['pappayalite.registration'].sudo().search_count([('email', '=', post.get('email'))]) > 0)
        if (is_already_registered):
            error_fields['email'] = 'Email already in use'

        #TODO: Check captcha
        
        if error_fields:
            _logger.info('ERRORS')
            _logger.info(error_fields)
            return(json.dumps({
                'status': 'error',
                'errorFields': error_fields,
                'message': 'Check error fields'
            }))

        # Remove last space from school name if present
        post['school_name'] = post.get('school_name').rstrip()

        # No Errors, Continue
        registration = request.env['pappayalite.registration'].sudo().create({
            'first_name': post.get('first_name'),
            'last_name': post.get('last_name'),
            'school_name': post.get('school_name'),
            'email': post.get('email'),
            'phone': post.get('phone'),
            'password': post.get('password'), #TODO: Hash password or just pass on and not store
            'address_1': post.get('street_number'),
            'address_2': post.get('route'),
            'address_city': post.get('locality'),
            'address_state': post.get('administrative_area_level_1'),
            'address_pincode': post.get('postal_code'),
            'address_country': post.get('country'),
        })

        namespace_prefix = request.env['ir.config_parameter'].sudo().get_param('build_namespace_prefix')
        odoo_username = request.env['ir.config_parameter'].sudo().get_param('build_odoo_username')
        build_tld = request.env['ir.config_parameter'].sudo().get_param('build_tld')
        build_app_registry = request.env['ir.config_parameter'].sudo().get_param('build_app_registry')
        build_app_repository = request.env['ir.config_parameter'].sudo().get_param('build_app_repository')
        build_app_version = request.env['ir.config_parameter'].sudo().get_param('build_app_version')
        build_max_cpu = request.env['ir.config_parameter'].sudo().get_param('build_max_cpu')
        build_max_memory = request.env['ir.config_parameter'].sudo().get_param('build_max_memory')
        build_storage_class = request.env['ir.config_parameter'].sudo().get_param('build_storage_class')

        build_slug = re.sub(r'\W+', '-', post.get('school_name'))
        is_build_available = request.env['pappayalite.tenant.build'].sudo().search([('build_name', '=', build_slug)])
        if is_build_available:
            build_slug += str(registration.id)

        if not namespace_prefix:
            namespace_prefix = 'pappayalite-test-'
        
        namespace = namespace_prefix + build_slug.lower()
        tenant_id = request.env['pappayalite.tenant.build'].sudo().create({
            'namespace': namespace,
            'build_name': namespace,
            'build_domain': build_slug.lower() + build_tld.lower(),
            'odoo_username': odoo_username,
            'app_registry' : build_app_registry,
            'app_repository' : build_app_repository,
            'app_version' : build_app_version,
            'max_cpu' : build_max_cpu,
            'max_memory' : build_max_memory,
            'storage_class' : build_storage_class,
        })

        if tenant_id:
            registration.write({'tenant_id': tenant_id})

        base_url = request.env['ir.config_parameter'].sudo().get_param('web.base.url')
        message = str(registration.id)
        message_bytes = message.encode('ascii')
        base64_bytes = base64.b64encode(message_bytes)
        base64_message = base64_bytes.decode('ascii')
        application_url = base_url + '/sucess/' + base64_message
        mail = request.env['mail.mail']
        email_from_obj = request.env['ir.mail_server'].sudo().search([], limit=1).smtp_user

        if not email_from_obj:
            raise UserError(_("Please configure outgoing email server address."))
        else:
            body =  request.env.ref('pappayalite_backend.mail_registration_details_data')._render({
                'name': post.get('first_name') + ' ' + post.get('last_name'),
                'form_link': application_url
            })
            mail_id = mail.sudo().create( {
                'subject': "PappayaLite ERP For %s" % (post.get('school_name')),
                'email_from': email_from_obj or False,
                'email_to': post.get('email'),
                'body_html': body,
                'message_type': 'email'
            })
            mail_id.send()

            response = self.signup_process()
            return response

    def signup_process(self):
        _logger.info('========signup_process========')
        qcontext = self.get_auth_signup_qcontext()

        if not qcontext.get('token') and not qcontext.get('signup_enabled'):
            raise werkzeug.exceptions.NotFound()
        if 'error' not in qcontext and request.httprequest.method == 'POST':
            _logger.info('========signup_process: %s', qcontext)
            self.do_signup(qcontext)

            if qcontext.get('token'):
                User = request.env['res.users']
                user_sudo = User.sudo().search(
                    User._get_login_domain(qcontext.get('login')), order=User._get_login_order(), limit=1
                )
                _logger.info('========signup_process: %s', user_sudo)
                template = request.env.ref('auth_signup.mail_template_user_signup_account_created', raise_if_not_found=False)
                if user_sudo and template:
                    template.sudo().send_mail(user_sudo.id, force_send=True)
            return werkzeug.utils.redirect('/web')

        response = request.render('auth_signup.signup', qcontext)
        response.headers['X-Frame-Options'] = 'DENY'
        return response

    def get_auth_signup_config(self):
        print ("========get_auth_signup_config")
        """retrieve the module config (which features are enabled) for the login page"""
        get_param = request.env['ir.config_parameter'].sudo().get_param
        return {
            'signup_enabled': request.env['res.users']._get_signup_invitation_scope() == 'b2c',
            'reset_password_enabled': get_param('auth_signup.reset_password') == 'True',
        }

    def get_auth_signup_qcontext(self):
        print ("========get_auth_signup_qcontext")
        """ Shared helper returning the rendering context for signup and reset password """
        qcontext = request.params.copy()

        if qcontext.get('first_name') and qcontext.get('last_name'):
            qcontext['name'] = qcontext['first_name'] + ' ' + qcontext['last_name']
        if qcontext.get('email') and qcontext.get('last_name'):
            qcontext['login'] = qcontext['email']
        if qcontext.get('street'):
            qcontext['login'] = qcontext['email']
        if qcontext.get('phone'):
            qcontext['phone'] = qcontext['phone']
        if qcontext.get('street_number'):
            qcontext['street'] = qcontext['street_number']
        if qcontext.get('route'):
            qcontext['street2'] = qcontext['route']
        if qcontext.get('locality'):
            qcontext['city'] = qcontext['locality']
        if qcontext.get('postal_code'):
            qcontext['zip'] = qcontext['postal_code']

        if qcontext.get('administrative_area_level_1'):
            state = request.env['res.country.state'].search([
                ('name', '=', qcontext.get('administrative_area_level_1'))
            ], limit=1)
            qcontext['state_id'] = state and state.id or False
        if qcontext.get('country'):
            country = request.env['res.country'].search([
                ('name', '=', qcontext.get('country'))
            ], limit=1)
            qcontext['country_id'] = country and country.id or False

        qcontext.update(self.get_auth_signup_config())

        if not qcontext.get('token') and request.session.get('auth_signup_token'):
            qcontext['token'] = request.session.get('auth_signup_token')
        if qcontext.get('token'):
            try:
                # retrieve the user info (name, login or email) corresponding to a signup token
                token_infos = request.env['res.partner'].sudo().signup_retrieve_info(qcontext.get('token'))
                for k, v in token_infos.items():
                    qcontext.setdefault(k, v)
            except:
                qcontext['error'] = _("Invalid signup token")
                qcontext['invalid_token'] = True
        return qcontext

    def _signup_with_values(self, token, values):
        error_fields = {}
        try:
            db, login, password = request.env['res.users'].sudo().signup(values, token)
            request.env.cr.commit()     # as authenticate will use its own cursor we need to commit the current transaction
            uid = request.session.authenticate(db, login, password)
            if not uid:
                raise SignupError(_('Authentication Failed.'))
        except ValueError as e:
            error_fields['Error'] = e
            return (json.dumps({
                'status': 'error',
                'errorFields': error_fields,
                'message': 'Registering user alredy avaialble in Google ad manager'
            }))


    def do_signup(self, qcontext):
        _logger.info('========do_signup========')
            
        """ Shared helper that creates a res.partner out of a token """
        values = { key: qcontext.get(key) for key in ('login', 'name', 'password')}

        if not values:
            raise UserError(_("The form was not properly filled in."))
        supported_lang_codes = [code for code, _ in request.env['res.lang'].get_installed()]
        lang = request.context.get('lang', '')
        if lang in supported_lang_codes:
            values['lang'] = lang
        if qcontext.get('type'):
            values['user_type'] = str(qcontext['type'].replace("'", ""))
        if qcontext.get('ad_compnay_name'):
            values['ad_compnay_name'] = str(qcontext['ad_compnay_name'].replace("'", ""))
        if qcontext.get('email'):
            values['email'] = qcontext['email']
        if qcontext.get('mobile'):
            values['mobile'] = qcontext['phone']
        if qcontext.get('phone'):
            values['phone'] = qcontext['phone']
        if qcontext.get('street_number'):
            values['street'] = qcontext['street_number']
        if qcontext.get('route'):
            values['street2'] = qcontext['route']
        if qcontext.get('locality'):
            values['city'] = qcontext['locality']
        if qcontext.get('postal_code'):
            values['zip'] = qcontext['postal_code']

        if qcontext.get('administrative_area_level_1'):
            state = request.env['res.country.state'].search([
                ('name', '=', qcontext.get('administrative_area_level_1'))
            ], limit=1)
            values['state_id'] = state and state.id or False
        if qcontext.get('country'):
            country = request.env['res.country'].search([
                ('name', '=', qcontext.get('country'))
            ], limit=1)
            values['country_id'] = country and country.id or False

        _logger.info('========do_signup: %s', qcontext)
        _logger.info('========do_signup: %s', values)
        self._signup_with_values(qcontext.get('token'), values)
        request.env.cr.commit()

    @http.route('/sucess/<string:token>', website=True, type='http', auth='none')
    def sucess_portal(self, token, **post):
        base64_bytes = token.encode('ascii')
        message_bytes = base64.b64decode(base64_bytes)
        message = message_bytes.decode('ascii')
        registration = request.env['pappayalite.registration'].sudo().search([('id','=',message)])
        registration.write({'state': 'requested'})
        record = registration.tenant_id
        if record:
            dict_data = {
                'namespace' : record.namespace,
                'build_name' : record.build_name,
                'build_domain' : record.build_domain,
                'odoo_username' : record.odoo_username,
                'app_registry' : record.app_registry,
                'app_repository' : record.app_repository,
                'app_version' : record.app_version,
                'max_cpu' : record.max_cpu,
                'max_memory' : record.max_memory,
                'storage_class' : record.storage_class,
            }
            headers = {
                'Content-Type': 'application/json'
            }
            tenant_api_url = request.env['ir.config_parameter'].sudo().get_param('tenant_api_url')
            url = str(tenant_api_url) + 'build/create'
            build = requests.request("POST", url, headers=headers, data=json.dumps(dict_data))
            record.write({'state': 'started'})
            print ("\n\n\n build create--->",build.text)
            if 'status' in build.text:
                data = json.loads(build.text)
                record.write({'status': data.get('status')})
                record.write({'message': data.get('message')})
        return request.render('pappayalite_backend.pappaya_sucess_page')

    @http.route('/pappayalite/school', type='json', auth='none')
    def getSchool(self, **kw):
        try:
            res = OrderedDict([
                ('status', 'success'),
                ('data', [])
            ])
            school = request.env['pappayalite.registration'].sudo().search([
                ('state', '=', 'ready'),
                ('school_code', '=', kw.get('code'))
            ], limit=1)
            if school:
                school_data = OrderedDict([
                    ('school_name', school.school_name),
                    ('school_url', school.build_domain)
                ])
                res['data'].append(school_data)
            else:
                res = OrderedDict([
                    ('status', 'failed'),
                    ('error', 'School not found')
                ])

        except Exception as e:
            res = OrderedDict([
                ('status', 'failed'),
                ('error', str(e))
            ])
        return res


    @http.route('/advertiser_registration', website=True, type='http', auth='none')
    def advertiser_registration_portal(self, **kw):
        return request.render('pappayalite_backend.pappaya_advertiser_registration_page', {
            'recaptcha_site_key': request.env['ir.config_parameter'].sudo().get_param('recaptcha_site_key')
        })

    @http.route('/advertiser_registration_save', methods=['post'], type='http', auth='public', csrf=False)
    def advertiser_registration_save(self, **post):
        _logger.info('========advertiser_registration_save========')
                
        # Validate required fields
        required_fields = ['first_name', 'last_name', 'email', 'phone', 'password', 'ad_compnay_name', 'street_number', 'route', 'locality', 'administrative_area_level_1', 'postal_code', 'country']
        error_fields = {}
        error_mail_cont = ''
        error_phone_cont = ''
        for field in required_fields:
            if (post.get(field) == ''):
                error_fields[field] = 'This is a required field'

        # Check if email exists
        userObj = request.env['res.users']
        partnerObj = request.env['res.partner']

        is_already_registered = userObj.sudo().search_count([('login', '=', post.get('email'))]) > 0
        if (is_already_registered):
            error_fields['email'] = 'Email already in use'
            error_mail_cont = 'Email already in use '


        # phone = post.get('phone').replace(' ', '')
        # post['phone'] = phone
        phone = post.get('phone')
        is_user_phone_found = partnerObj.sudo().search_count(['|', ('phone', '=', phone), ('mobile', '=', phone)]) > 0
        if (is_user_phone_found):
            error_fields['phone'] = 'Phone number already in use'
            error_phone_cont = "Phone number already in use"

        #TODO: Check captcha
        if error_fields:
            _logger.info('=======ERRORS=====')
            _logger.info(error_fields)
            # return(json.dumps({
            #     'status': 'error',
            #     'errorFields': error_fields,
            #     'message': 'Check error fields'
            # }))
            return request.render('pappayalite_backend.pappaya_registration_validation',
                                  {'errorMail':error_mail_cont,
                                   'errorPhone':error_phone_cont})

        # base_url = request.env['ir.config_parameter'].sudo().get_param('web.base.url')
        # message = str(registration.id)
        # message_bytes = message.encode('ascii')
        # base64_bytes = base64.b64encode(message_bytes)
        # base64_message = base64_bytes.decode('ascii')
        # application_url = base_url + '/sucess/' + base64_message

        # mail = request.env['mail.mail']
        # email_from_obj = request.env['ir.mail_server'].sudo().search([], limit=1).smtp_user

        # if not email_from_obj:
        #     raise UserError(_("Please configure outgoing email server address."))
        # else:
        #     name = post.get('first_name') + ' ' + post.get('last_name')
        #     body =  request.env.ref('pappayalite_backend.mail_registration_details_data')._render({
        #         'name': name
        #         # 'form_link': application_url
        #     })
        #     mail_id = mail.sudo().create( {
        #         'subject': "PappayaLite advertiser registration for %s" % (name),
        #         'emal_from': email_from_obj,
        #         'email_to': post.get('email'),
        #         'body_html': body,
        #         'message_type': 'email'
        #     })
        #     mail_id.send()

        response = self.signup_process()
        return response
