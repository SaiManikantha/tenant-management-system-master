( function( $ ) {

"use strict";

// *** On ready *** //
$( document ).on("ready" , function() {
	responsiveClasses();
	dataCustomOptions();
	fullscreenSection();
	scrollToAnchor();
	bannerParallaxImageBG();
	sectionParallaxImageBG();
	registrationForm();
	scrollTopIcon();
});

// *** On load *** //
$(window).on("load" , function() {
	parallaxStellar();
	scrollProgress();
});

// *** On resize *** //
$(window).on("resize" , function() {
	responsiveClasses();
	fullscreenSection();
	parallaxStellar();
});

// *** On scroll *** //
$(window).on("scroll" , function() {
	scrollTopIcon();
	scrollProgress();
});

// *** On Scroll In On load *** //
$(window).on("load" , function() {
	$(window).on("scroll" , function() {

	});
});


// *** jQuery noConflict *** //
var $ = jQuery.noConflict();


// *** General Variables *** //
var $window = $(window),
	$this = $( this ),
	$body = $("body");

// *** Data Custom Options *** //
function dataCustomOptions(){$("*[data-pattern-overlay-darkness-opacity]").each(function(){var a=$(this).data("pattern-overlay-darkness-opacity");$(this).css("background-color",convertHex("#000000",a))}),$("*[data-pattern-overlay-background-image]").each(function(){"none"==$(this).data("pattern-overlay-background-image")?$(this).css("background-image","none"):"yes"==$(this).data("pattern-overlay-background-image")&&$(this).css("background-image")}),$("*[data-remove-pattern-overlay]").each(function(){"yes"==$(this).data("remove-pattern-overlay")&&$(this).css("background","none")}),$("*[data-bg-color]").each(function(){var a=$(this).data("bg-color");$(this).css("background-color",a)}),$("*[data-bg-color-opacity]").each(function(){var a=$(this).data("bg-color-opacity"),t=$(this).css("background-color").replace("rgb","rgba").replace(")",", "+a+")");$(this).css("background-color",t)}),$("*[data-bg-img]").each(function(){var a=$(this).data("bg-img");$(this).css("background-image","url('"+a+"')")}),$("*[data-parallax-bg-img]").each(function(){var a=$(this).data("parallax-bg-img");$(this).css("background-image","url('./images/files/parallax-bg/"+a+"')")})}


// Custom banner height
$(".banner-parallax").each(function() {
	var customBannerHeight = $( this ).data("banner-height"),
		boxContent = $( this ).find(".row > [class*='col-']");
	$( this ).css("min-height" , customBannerHeight );
	$( boxContent ).css("min-height" , customBannerHeight );
});


// *** Responsive Classes *** //
function responsiveClasses() {
	var jRes = jRespond([
		{
			label: "smallest",
			enter: 0,
			exit: 479
		},{
			label: "handheld",
			enter: 480,
			exit: 767
		},{
			label: "tablet",
			enter: 768,
			exit: 991
		},{
			label: "laptop",
			enter: 992,
			exit: 1199
		},{
			label: "desktop",
			enter: 1200,
			exit: 10000
		}
	]);
	jRes.addFunc([
		{
			breakpoint: "desktop",
			enter: function() { $body.addClass("device-lg"); },
			exit: function() { $body.removeClass("device-lg"); }
		},{
			breakpoint: "laptop",
			enter: function() { $body.addClass("device-md"); },
			exit: function() { $body.removeClass("device-md"); }
		},{
			breakpoint: "tablet",
			enter: function() { $body.addClass("device-sm"); },
			exit: function() { $body.removeClass("device-sm"); }
		},{
			breakpoint: "handheld",
			enter: function() { $body.addClass("device-xs"); },
			exit: function() { $body.removeClass("device-xs"); }
		},{
			breakpoint: "smallest",
			enter: function() { $body.addClass("device-xxs"); },
			exit: function() { $body.removeClass("device-xxs"); }
		}
	]);
}


// *** Fullscreen Section *** //
function fullscreenSection() {
	$(".fullscreen, #home-header, #home-banner").css("height", $(window).height() );
	$("#banner.fullscreen").css("height", $(window).height() );
}


// *** Stellar Parallax *** //
function parallaxStellar() {
	$(function() {
		if ( $body.hasClass("device-lg") || $body.hasClass("device-md") || $body.hasClass("device-sm") ) {
			$.stellar({
				horizontalScrolling: false, // don't change this option
				// verticalScrolling: false,
				verticalOffset: 0,
				responsive: true, // false
			});
		}
	});
}


// *** Scroll Top Icon *** //
function scrollTopIcon() {
	var windowScroll = $(window).scrollTop();
	if ( $(window).scrollTop() > 800 ) {
		$(".scroll-top-icon").addClass("show");
	} else {
		$(".scroll-top-icon").removeClass("show");
	}
}

$(".scroll-top").on("click", function(e) {
	e.preventDefault();
	$("html, body").animate({
		scrollTop: 0
	}, 1200, "easeInOutExpo"); //1200 easeInOutExpo
});


// *** Scroll Progress *** //
function scrollProgress() {
	var docheight = $(document).height();
	var winheight = $(window).height();
	var height = docheight - winheight;
	var scroll = $(document).scrollTop();
	var scrollperc = scroll/(height/100);
	$("#scroll-progress .scroll-progress").width(scrollperc+'%');
	$(".scroll-percent").text(scrollperc.toFixed(0)+'%');	
}


// *** Scroll To Anchor *** //
function scrollToAnchor() {
	var stickyBar = $(".header-bar.sticky"),
		stickyBarHeight = stickyBar.height(),
		offsetDifference = (!stickyBar) ? 0 : stickyBarHeight;

	$(".scroll-to").on("click", function(e) {
		e.preventDefault();
		var $anchor = $(this);

		// scroll to specific anchor
		$("html, body").stop().animate({
			scrollTop: $( $anchor.attr("href")).offset().top - offsetDifference
		}, 1200, "easeInOutExpo");
	});    
}


// *** Banner Parallax Image BG *** //
function bannerParallaxImageBG() {
	var bannerParallax = $(".banner-parallax"),
		imgSrc = bannerParallax.children("img:first-child").attr("src");

	bannerParallax.prepend("<div class='bg-element'></div>");
	var bgElement = bannerParallax.find("> .bg-element");
	bgElement.css("background-image", "url('" + imgSrc + "')"  ).attr("data-stellar-background-ratio" , 0.2 );
}


// *** Section Parallax Image BG *** //
function sectionParallaxImageBG() {
	$(".parallax-section").each( function() {
		var parallaxSection = $( this ),
			imgSrc = parallaxSection.children("img:first-child").attr("src");

		parallaxSection.prepend("<div class='bg-element'></div>");
		var bgElement = parallaxSection.find("> .bg-element");
		bgElement.css("background-image", "url('" + imgSrc + "')"  ).attr("data-stellar-background-ratio" , 0.2 );
	} );
}


// *** Scroll To *** //
$(".scroll-to").on("click", function(e) {
	e.preventDefault();
	var $anchor = $(this);      

	// scroll to specific anchor
	$("html, body").stop().animate({
		scrollTop: $( $anchor.attr("href")).offset().top
	}, 1200, "easeInOutExpo");
});    


// *** Registration Form *** //
var csNotifications = $(".cs-notifications");

function registrationForm() {
	$("#registration").validate({
        ignore: [],
		// rules
		rules: {
			first_name: {
				required: true,
				minlength: 3
			},
			last_name: {
				required: true,
				minlength: 3
			},
			email: {
				required: true,
				email: true
			},
			phone: {
				required: true,
				minlength: 9,
				maxlength: 15
			},
			password: {
				required: true,
				minlength: 6
			},
			school_name: {
				required: true,
				minlength: 6
			},
			address: {
				required: true
			},
			street_number: {
				required: true
			},
			locality: {
				required: true
			},
			administrative_area_level_1: {
				required: true
			},
			postal_code: {
				required: true,
				minlength: 5,
				maxlength: 15
			},
			country: {
				required: true
			}
		}
	});

	var errorMsgData = csNotifications.data("error-msg"),
		errorMsgDefault = 'Please Follow Error Messages and Complete as Required',
		errorMsg = ( errorMsgData ) ? ( errorMsgData ) : errorMsgDefault;

	// Submit event
	$("#registration").on("submit", function(event) {
		if (grecaptcha.getResponse() == "") {
			event.preventDefault();
			$('.g-recaptcha iframe').addClass('captcha-error')
			submitMSG(false, '<i class="cs-error-icon fas fa-times"></i> Captcha Error');
			formError();
		} else if (event.isDefaultPrevented()) {
			var errorContent = '<i class="cs-error-icon fas fa-times"></i>' + errorMsg;
			submitMSG(false, errorContent);
			formError();
		} else {
			event.preventDefault();
			submitForm();
		}
	});
}

function submitForm(){
	var $form = $('#registration');
	var $submitBtn = $('#registration .submit_btn');
    var unindexed_array = $form.serializeArray();
    var data = {};

    $.map(unindexed_array, function(n, i){
        data[n['name']] = n['value'];
    });
	$submitBtn.attr('disabled', '')
	
	$.ajax({
		type: 'POST',
		dataType: 'json',
		url: $form.attr('action'),
		data: data,
		success: function(result){
			if (result.status == 'success'){
				csNotifications.data('success-msg', result.message)
				registrationSuccess();
			} else {
				if (result.errorFields) {
					var validator = $form.validate();
					validator.showErrors(result.errorFields);
				}
				submitMSG(false, result.message);
				formError();
				$submitBtn.removeAttr('disabled')
			}
		}
	});
}

function registrationSuccess() {
    $("#registration")[0].reset()
	$("#registration .form-group").hide()
	grecaptcha.reset()
	submitMSG(!0, '<i class="cs-success-icon fas fa-check"></i>' + csNotifications.data("success-msg"))
	$(".cs-notifications-content").addClass("sent")
	csNotifications.css("opacity", 0)
	$('html,body').animate({
		scrollTop: $('#main-form').offset().top
	}, 500);
	csNotifications.slideDown(300).animate({
        opacity: 1
    }, 300).delay(5e3)
}

function formError() {
    csNotifications.css("opacity", 0)
	csNotifications.slideDown(300).animate({
        opacity: 1
    }, 300)
	$(".cs-notifications-content").removeClass("sent")
}

function submitMSG(i, s) {
    var n;
    n = "shake animated"
	csNotifications.delay(300).addClass(n).one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend", function() {
        $(this).removeClass("shake bounce animated")
    })
	csNotifications.children(".cs-notifications-content").html(s)
}

//
// ----- Custom ------
// 

let telInput = $("#mce-PHONE")
telInput.intlTelInput({
	initialCountry: 'auto',
	preferredCountries: ['in'],
	separateDialCode: true,
	autoPlaceholder: 'aggressive',
	utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/12.1.6/js/utils.js",
	geoIpLookup: function(callback) {
		fetch('https://ipinfo.io/json', {
			cache: 'reload'
		}).then(response => {
			if (response.ok) {
				callback(response.json().country)
			} else {
				throw new Error('Failed: ' + response.status)
			}
		}).catch(e => {
			callback('in')
		})
	}
})

//view password
$('.viewpwd').click(function(){
	$('.hidepwd').show();
	$(this).hide();
	$(this).parent('.form-group').find('input').attr('type','text')
});
$('.hidepwd').click(function(){
	$('.viewpwd').show();
	$(this).hide();
	$(this).parent('.form-group').find('input').attr('type','password')
})


var autocomplete;
var componentForm = {
	street_number: 'short_name',
	route: 'long_name',
	locality: 'long_name',
	administrative_area_level_1: 'long_name',
	postal_code: 'short_name',
	country: 'long_name'
};

function initAutocomplete() {
	autocomplete = new google.maps.places.Autocomplete(document.getElementById('mce-Address'), {
		types: ['geocode']
	});
	autocomplete.setFields(['address_components']);
	autocomplete.addListener('place_changed', fillInAddress);
}
initAutocomplete();

function fillInAddress() {
	// Get the place details from the autocomplete object.
	var place = autocomplete.getPlace();
	for (var component in componentForm) {
		document.getElementById(component).value = '';
		document.getElementById(component).disabled = false;
	}

	// Get each component of the address from the place details,
	// and then fill-in the corresponding field on the form.
	for (var i = 0; i < place.address_components.length; i++) {
		var addressType = place.address_components[i].types[0];
		if (componentForm[addressType]) {
			var val = place.address_components[i][componentForm[addressType]];
			document.getElementById(addressType).value = val;
		}
	}

	setTimeout(function(){
		$('.form-field').each(function(){
			if($(this).val() == ""){
				$(this).addClass('errborder');
				$('.form-err').show();
			}else{
				$(this).removeClass('errborder')
				$('.form-err').hide();
			}
		})
	},1000);
	$('#address').show();
	$('input').each(function(){
		if($(this).val() != ""){
			$(this).removeClass('errorfield');
		}
	});
}
// Hide autopopulate details in form
$('#registration input').focus(function() {
	$(this).attr('autocomplete', 'none');
});
} )( jQuery );


function recaptchaCallback() { 
	jQuery('.g-recaptcha iframe').removeClass('captcha-error')
}


function convertHex( hex , opacity ){
	// "use strict";
	// var r, g, b, result;
	hex = hex.replace( '#' , '' );
	r = parseInt( hex.substring( 0 , 2 ) , 16 );
	g = parseInt( hex.substring( 2 , 4 ) , 16 );
	b = parseInt( hex.substring( 4 , 6 ) , 16 );

	result = 'rgba('+r+', '+g+', '+b+', '+opacity+')';
	return result;
}
