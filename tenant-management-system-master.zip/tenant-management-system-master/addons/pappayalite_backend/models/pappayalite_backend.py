# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import AccessError, UserError
import requests
import json
import logging


_logger = logging.getLogger(__name__)

class PappayaRegistrations(models.Model):
    _name = 'pappayalite.registration'
    _description = "Registration"

    first_name = fields.Char('First Name')
    last_name = fields.Char('Last Name')
    password = fields.Char('Password')
    phone = fields.Char('Phone', size=10)
    email = fields.Char('Email', readonly=True)
    school_name = fields.Char('School Name', required=True)
    school_code = fields.Char('School Code')
    build_domain = fields.Char('Build domain')

    address_1 = fields.Text('School Address Line 1')
    address_2 = fields.Text('School Address Line 2')
    address_city = fields.Text('School City')
    address_state = fields.Text('School State')
    address_pincode = fields.Text('School Pin Code')
    address_country = fields.Text('School Country')

    tenant_id = fields.Many2one('pappayalite.tenant.build', string='Tenant Detail', readonly=True)
    state = fields.Selection([
        ('requested', 'Requested'),
        ('ready', 'Ready'),
    ], default='requested', readonly=True)

    # This function is triggered when the user clicks on the button 'Ready'
    # @api.one
    def ready_progressbar(self):
        self.write({
            'state': 'ready',
            'school_code': self.env['ir.sequence'].next_by_code('pappayalite.registration')
        })

    # @api.multi
    def unlink(self):
        raise AccessError('Sorry, you are not authorized to delete record')

    # @api.one
    def copy(self, default=None):
        raise AccessError("You are not allowed to Duplicate")


class PappayaTenantBuild(models.Model):
    _name = 'pappayalite.tenant.build'
    _inherit = 'mail.thread'
    _description = "PappayaLite Tenant Build"

    name = fields.Char('Name', related='namespace')
    namespace = fields.Char('Namespace', readonly=True, required=True)
    build_name = fields.Char('Build name', readonly=True, required=True)
    build_domain = fields.Char('Build domain', readonly=True, required=True)
    odoo_username = fields.Char('Odoo username', readonly=True, required=True)
    app_registry = fields.Char('App registry', tracking=True)
    app_repository = fields.Char('App repository', tracking=True)
    app_version = fields.Char('App version', tracking=True)
    max_cpu = fields.Char('Max cpu', tracking=True)
    max_memory = fields.Char('Max memory', tracking=True)
    storage_class = fields.Char('Storage class', readonly=True)
    message = fields.Char('Build API response message')
    is_mail_send = fields.Boolean('Initial mail sent to user with login details', default=False)
    needs_build_update = fields.Boolean('Field value changed, needs build update')
    run_number_of_time = fields.Integer('Number of time run status checks', default=0)
    registration_id = fields.One2many('pappayalite.registration', 'tenant_id', limit=1, readonly=True)
    build_failed_mail_sent = fields.Boolean()
    _sql_constraints = [('unique_namespace_build_name_', 'unique (namespace, build_name)', 'namespace and build_name must be unique..!')]
    state = fields.Selection([
        ('new', 'New'),
        ('started', 'Build Started'),
        ('ready', 'Ready'),
        ('pending', 'Pending update'),
        ('failed', 'Failed'),
        ('archived', 'Archived'),
    ], default='new')
    status = fields.Selection([
        ('success', 'Success'),
        ('error', 'Error')
    ], string='Build API response status')

    @api.constrains('namespace', 'build_name')
    def _unique_namespace_build_name(self):
        if self.namespace:
            namespace = self.search([
                ('namespace', '=', self.namespace)], limit=2)
            if len(namespace) > 1:
                raise ValidationError(_('Namespace must be unique!'))
        if self.build_name:
            namespace = self.search([
                ('build_name', '=', self.build_name)], limit=2)
            if len(namespace) > 1:
                raise ValidationError(_('Build_name must be unique!'))

    @api.onchange('app_registry', 'app_repository', 'app_version', 'max_cpu', 'max_memory')
    def change_details(self):
        self.write({'state': 'pending'})

    # @api.multi
    def unlink(self):
        raise AccessError('Sorry, you are not authorized to delete record')

    # @api.one
    def copy(self, default=None):
        raise AccessError("You are not allowed to Duplicate")

    def check_tenant_build_status(self):
        tenant_builds = self.env['pappayalite.tenant.build'].sudo().search([('state', 'in', ['started'])])

        if tenant_builds:
            build_status_endpoint = self.env['ir.config_parameter'].sudo().get_param('tenant_api_url') + 'build/status'
            run_limit = int(self.env['ir.config_parameter'].sudo().get_param('build_schedular_limit'))
            if not run_limit:
                run_limit = 20

            for tenant_build in tenant_builds:
                if tenant_build.run_number_of_time >= run_limit:
                    tenant_build.write({
                        'status': 'error',
                        'state': 'failed',
                        'message': 'Exceeded API call limit for status check'
                    })

                try:
                    url = build_status_endpoint + '?build_name=' + tenant_build.build_name + '&namespace=' + tenant_build.namespace
                    build_status_response = requests.request('GET', url)
                    build_status_data = build_status_response.json()
                    tenant_build.run_number_of_time += 1

                    if build_status_data.get('build_status') == 'deployed' and \
                            build_status_data.get('odoo_pod_status') == 'running' and \
                            build_status_data.get('postgresql_pod_status') == 'running' and \
                            build_status_data.get('odoo_app_status') == 'running' and \
                            build_status_data.get('postgresql_app_status') == 'running':
                        mail_template = self.env.ref('pappayalite_backend.pappaya_email_template_check_build_status').sudo()
                        if mail_template:
                            mail_template.send_mail(tenant_build.id, force_send=True)
                        tenant_build.write({
                            'status': 'success',
                            'message': 'Build is up and running',
                            'state': 'ready',
                            'is_mail_send': True
                        })

                        logging.warning('1....Build Restart API Call.....................')
                        restart_build_status_endpoint = self.env['ir.config_parameter'].sudo().get_param('tenant_api_url') + 'build/restart'
                        res_url = restart_build_status_endpoint + '?pod_name=' + tenant_build.build_name + '&namespace=' + tenant_build.namespace
                        res_build_status_response = requests.request('GET', res_url)
                        res_build_status_data = res_build_status_response.json()
                        logging.warning('2....... Build JSON Response......',res_build_status_data)
                except Exception as err:
                    tenant_build.write({
                        'status': 'error',
                        'message': 'Status check: ' + str(err),
                        'state': 'failed'
                    })

    def check_tenant_fields_status(self):
        tenant_builds = self.env['pappayalite.tenant.build'].sudo().search([('state', 'in', ['pending'])])

        if tenant_builds:
            build_update_endpoint = self.env['ir.config_parameter'].sudo().get_param('tenant_api_url') + 'build/update'
            for tenant_build in tenant_builds:
                data = json.dumps({
                    'namespace' : tenant_build.namespace,
                    'build_name' : tenant_build.build_name,
                    'build_domain' : tenant_build.build_domain,
                    'odoo_username' : tenant_build.odoo_username,
                    'app_registry' : tenant_build.app_registry,
                    'app_repository' : tenant_build.app_repository,
                    'app_version' : tenant_build.app_version,
                    'max_cpu' : tenant_build.max_cpu,
                    'max_memory' : tenant_build.max_memory,
                    'storage_class' : tenant_build.storage_class,
                    'smtp_host': self.env['ir.config_parameter'].sudo().get_param('smtp_host'),
                    'smtp_port': self.env['ir.config_parameter'].sudo().get_param('smtp_port'),
                    'smtp_user': self.env['ir.config_parameter'].sudo().get_param('smtp_user'),
                    'smtp_password': self.env['ir.config_parameter'].sudo().get_param('smtp_password'),
                    'smtp_protocol': self.env['ir.config_parameter'].sudo().get_param('smtp_protocol'),
                })
                headers = {'Content-Type': 'application/json'}

                try:
                    build_update_response = requests.request('POST', build_update_endpoint, headers=headers, data=data)
                    build_update_data = build_update_response.json()
                    if build_update_data.status == 'success':
                        tenant_build.write({'state': 'started'})
                    else:
                        raise Exception(build_update_data.message)
                except Exception as err:
                    tenant_build.write({
                        'status': 'error',
                        'message': 'Update: ' + str(err),
                        'state': 'failed'
                    })

    def check_tenant_failed_status(self):
        tenant_builds = self.env['pappayalite.tenant.build'].sudo().search([('state', 'in', ['failed']), ('build_failed_mail_sent', '=', False)])

        if tenant_builds:
            mail_template = self.env.ref('pappayalite_backend.pappaya_email_template_check_build_failed_status').sudo()
            for tenant_build in tenant_builds:
                tenant_build.build_failed_mail_sent = True
                mail_template.send_mail(tenant_build.id, force_send=True)

    def reset_state_build_started(self):
        self.state = 'started'
        self.build_failed_mail_sent = False

    def reset_state_ready(self):
        self.state = 'ready'

class ResConfigDataSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    namespace_prefix = fields.Char('Name Space', config_parameter='build_namespace_prefix')
    odoo_username = fields.Char('Odoo Username', config_parameter='build_odoo_username')
    app_registry = fields.Char('App Registry', config_parameter='build_app_registry')
    app_repository = fields.Char('App Repository', config_parameter='build_app_repository')
    app_version = fields.Char('App Version', config_parameter='build_app_version')
    max_cpu = fields.Char('Max CPU', config_parameter='build_max_cpu')
    max_memory = fields.Char('Max Memory', config_parameter='build_max_memory')
    storage_class = fields.Char( 'Storage Class', config_parameter='build_storage_class')
    build_tld = fields.Char('Storage Class', config_parameter='build_tld')
    limit_set = fields.Integer( 'Limit set to schedular', config_parameter='build_schedular_limit')
    tenant_api_url = fields.Char('URL', config_parameter='tenant_api_url')
    smtp_host = fields.Char('URL', config_parameter='smtp_host')
    smtp_port = fields.Char('URL', config_parameter='smtp_port')
    smtp_user = fields.Char('URL', config_parameter='smtp_user')
    smtp_password = fields.Char('URL', config_parameter='smtp_password')
    smtp_protocol = fields.Char('URL', config_parameter='smtp_protocol')
    recaptcha_site_key = fields.Char('ReCaptcha Site Key', config_parameter='recaptcha_site_key')
