from .hooks import _auto_install_modules
