# -*- coding: utf-8 -*-
{
    'name': 'Pappaya Autoinstall',
    'version': '1',
    'license': 'LGPL-3',
    'category': 'Pappaya',
    'sequence': 1,
    'summary': 'Install required modules',
    'author': 'Pappaya',
    'website': 'https://www.pappaya.com',
    'depends': [],
    'data': [],
    'auto_install': True,
    'installable': True,
    'application': True,
    'qweb': [],
    'pre_init_hook': '_auto_install_modules',
}