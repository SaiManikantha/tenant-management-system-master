from odoo import SUPERUSER_ID, api
import logging


_logger = logging.getLogger(__name__)

def _auto_install_modules(cr):
    list = [
        ('pappaya_theme'),
        ('pappayalite_backend'),
        ('pappayalite_crm'),
        ('web_debranding'),
    ]
    env = api.Environment(cr, SUPERUSER_ID, {})
    moduleIds = env['ir.module.module'].search([
        ('state', '!=', 'installed'),
        ('name', 'in', list)
    ])

    if moduleIds:
        _logger.info(moduleIds)
        moduleIds.button_install()