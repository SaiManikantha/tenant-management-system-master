# -*- coding: utf-8 -*-

{
    'name'      : "Pappaya Theme",
    "summary"   : "Theme for V12",
    'author'    : 'Pappaya',
    'website'   : '//www.pappaya.com',
    "category"  : "Themes/Backend",
    'version'   : '14.0.0.1',
    "license"   : "LGPL-3",
    "depends"   : ["web"],
    "data"      : [
                    'views/assets.xml',
                    'views/web.xml',
                ],
    'qweb'      : [
                    "static/src/xml/web.xml",
                ],
    "images"        : ['static/description/icon.jpg'],
    'installable'   : True,
    'application'   : True,
    'auto_install'  : False,
}