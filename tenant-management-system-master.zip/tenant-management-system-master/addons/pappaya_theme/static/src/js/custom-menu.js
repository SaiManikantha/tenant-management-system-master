odoo.define('pappaya_theme.custom_menu', function(require) {
    "use strict";
    var config = require('web.config');
    var core = require('web.core');
    var SystrayMenu = require('web.SystrayMenu');
    var UserMenu = require('web.UserMenu');
    UserMenu.prototype.sequence = 0; // force UserMenu to be the right-most item in the systray
    SystrayMenu.Items.push(UserMenu);
    var custom_menu = require('web.Menu');


    custom_menu.include({
        _onMouseOverMenu: function (ev) {
            if (config.device.isMobile) {
                return;
            }
            $('.dropdown-item').click(function(){
                $('.o_menu_sections li').removeClass('active-menu');
                $(this).closest('li').addClass('active-menu');
            });
            $('.o_menu_entry_lvl_1').click(function(){
                $('.o_menu_sections li').removeClass('active-menu');
                $('.o_menu_entry_lvl_1').closest('li').removeClass('active-menu');
                $(this).closest('li').addClass('active-menu');
            })
        },
    });
});
