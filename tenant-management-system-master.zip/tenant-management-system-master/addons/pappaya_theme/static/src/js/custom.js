odoo.define('pappaya_theme.custom', function (require) {
	"use strict";
	// $(document).ready(function () {
		// $('.o_menu_sections').click(function(){
		// 	alert('yes');
		// 	$('.o_menu_sections li').removeClass('active-menu');
		// 	$(this).addClass('active-menu');
		// })
		$('.o_menu_header_lvl_1').on('click', function(){
			$(this).next('.dropdown-menu').slideToggle(500);
			console.log('asfdsafsadfsadfsafdsda');
		});
	// });
});
