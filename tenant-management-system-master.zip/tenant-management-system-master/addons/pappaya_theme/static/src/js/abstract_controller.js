odoo.define('pappaya_theme.AbstractController', function (require) {
    "use strict";
    var session = require('web.session');
    var customAbstractController = require('web.AbstractController');
    var session = require('web.session');
    
    customAbstractController.include({
        _startRenderer: function () {
            if (this.renderer instanceof owl.Component) {
                return this.renderer.mount(this.$('.o_content')[0]);
            }
            $('.o_menu_sections .dropdown-menu').removeClass('show');
            $('.o_menu_header_lvl_1').on('click', function(){
                $('.o_menu_sections li').removeClass('togglemenu');
                $(this).closest('li').addClass('togglemenu');
                $('.dropdown-menu').hide();
                $(this).next('.dropdown-menu').slideDown(200);
            });
            $('.o_menu_entry_lvl_2').on('click', function(){
                $('.o_menu_entry_lvl_2').removeClass('active-leafmenu');
                $(this).addClass('active-leafmenu');
            });
            $('.hamburger-menu').unbind("click").click(function(e){
                $('body').toggleClass('menu-collapse');
                console.log('resar');
            });
            // var isAdmin = session.is_admin;
            // if(isAdmin){
            //     $('body').addClass('adminuser');
            // }
            session.user_has_group('base.group_system').then(function(has_group){
                // console.log('user_has_group', has_group);
                if(!has_group){
                    $('body').addClass('notadminuser');
                }
            }); 
            // console.log('session --' , session);
            return this.renderer.appendTo(this.$('.o_content'));
        },
    });
});
