odoo.define('pappayalite_crm.hide_action_buttons', function (require) {
    "use strict";
    let FormView = require('web.FormView');
    var rpc = require('web.rpc');
    FormView.include({
        init: function (viewInfo, params) {
            this._super.apply(this, arguments);
            if (viewInfo && viewInfo.model == 'crm.lead'){
                if(this && this.controllerParams && this.controllerParams.hasActionMenus){
                    this.controllerParams.hasActionMenus = false;
                }
            }
        }
    });
});