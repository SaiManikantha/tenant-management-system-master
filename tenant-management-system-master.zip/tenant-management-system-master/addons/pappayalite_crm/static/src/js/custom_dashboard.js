odoo.define('pappayalite_crm.dashboard', function(require) {
    "use strict";

    var core = require('web.core');
    var framework = require('web.framework');
    var session = require('web.session');
    var ajax = require('web.ajax');
    var ActionManager = require('web.ActionManager');
    var view_registry = require('web.view_registry');
    var Widget = require('web.Widget');
    var AbstractAction = require('web.AbstractAction');
    var ControlPanelMixin = require('web.ControlPanelMixin');
    var QWeb = core.qweb;

    var _t = core._t;
    var _lt = core._lt;

    var CustomDashbaordView = AbstractAction.extend(ControlPanelMixin, {
        events: {
        },
        init: function(parent, context) {
            this._super(parent, context);
        },
        start: function() {
            var self = this;
            return this._super();
        },
        render: function() {
            var super_render = this._super;
            var self = this;
            var hr_dashboard = QWeb.render('CustomDashbaord', {
                widget: self,
            });
            $(".o_control_panel").addClass("o_hidden");
            $(hr_dashboard).prependTo(self.$el);
            self.graph();
            self.previewTable();
            return hr_dashboard
        },
    });
    core.action_registry.add('pappayalite_crm.dashboard', CustomDashbaordView);
    return CustomDashbaordView
});

