# -*- coding: utf-8 -*-
{
    'name': 'PappayaLite CRM',
    'version': '14.0.0.0.1',
    'category': 'Pappaya',
    "sequence": 1,
    'author': 'Pappaya',
    'website': 'https://www.pappaya.com',
    'depends': ['base', 'web', 'crm', 'board', 'crm_iap_lead', 'pappayalite_backend'],
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'data/data.xml',
        'wizard/crm_lead_wizard_view.xml',
        'views/assets.xml',
        'views/view.xml',
        'views/crm.xml',
        'views/res_partner.xml',
        'views/template.xml',
        'views/customer_view.xml',
        # 'views/ad_list_view.xml',
        'views/flight_view.xml',
    ],
    'qweb': [
        'static/src/xml/web.xml',
    ],
    'installable': True,
    'application': True,
}
