# -*- coding: utf-8 -*-
import time
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
from datetime import datetime, date


class CrmLeadWizard(models.TransientModel):
    _name = 'crm.lead.wizard'

    def pay_recharge_submit(self):
        active_ids = self._context.get('active_ids')
        lead_id = self.env['crm.lead'].browse(active_ids)
        lead_id.write({
            'states' : 'submitted'
            })
        return lead_id
