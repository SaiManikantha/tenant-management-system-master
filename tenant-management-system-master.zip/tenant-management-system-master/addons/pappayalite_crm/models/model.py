# -*- coding: utf-8 -*-
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import AccessError, UserError, ValidationError


class AdVerificationScreen(models.Model):
    _name = 'ad.verification'

    name = fields.Char('Customer Name', required=True)
    ad_name = fields.Char('Ad Name')
    ad_type = fields.Selection([('header_banner', 'Header banner'), ('leader_board_top', 'Leader board top'),
                               ('leader_board_bottom', 'Leader board bottom'),('login_half_page', 'Login half page')],
                                 string='Ad Type')
    ad_validfrom = fields.Date('Ad Valid From')
    ad_validto = fields.Date('Ad Valid To')
    status = fields.Char('Status')
    state = fields.Selection([('submitted', 'Submitted'), ('verified', 'Verified'), ('uploaded', 'Uploaded')], string='States', default='submitted')
    ad_crm_details_id = fields.Many2one('crm.lead', string='Customer Ad details')

    def ad_verify(self):
        self.write({
        'state': 'verified'
        })

    def ad_upload(self):
        self.write({
        'state': 'uploaded'
        })
