# -*- coding: utf-8 -*-
from odoo import api, fields, models, SUPERUSER_ID, _
from ast import literal_eval
from odoo.addons.auth_signup.models.res_partner import SignupError, now
from odoo.tools.misc import ustr
from odoo.exceptions import AccessError, UserError, ValidationError, Warning


class CustomCRM(models.Model):
    _inherit = "crm.lead"

    name = fields.Char(
        'Ad Name', index=True,required=False,
        compute='_compute_name', readonly=False, store=True)
    partner_id = fields.Many2one(
        'res.partner', string='Customer Name', index=True, tracking=10, readonly=True,
        domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]",
        help="Linked partner (optional). Usually created when converting the lead. You can find a partner by its Name, TIN, Email or Internal Reference.")

    customer = fields.Char('Customer Name')
    contact_name = fields.Char(
        'Customer First Name ',
        compute='_compute_contact_name', readonly=False, store=True)
    function = fields.Text('Description of the customer', compute='_compute_function', readonly=False, store=True)
    mobile = fields.Char('Mobile Number', compute='_compute_mobile', readonly=False, store=True)
    email_from = fields.Char(
        'Company Email', tracking=40, index=True,
        compute='_compute_email_from', inverse='_inverse_email_from', readonly=False, store=True)
    phone = fields.Char(
        'Telephone Number', tracking=50,
        compute='_compute_phone', inverse='_inverse_phone', readonly=False, store=True)
    description = fields.Text('Ad Text')
    expected_revenue = fields.Monetary('Expected Revenue', currency_field='company_currency', tracking=True)
    states = fields.Selection([('submitted', 'Submitted'), ('verified', 'Verified'),('uploaded', 'Uploaded')], string='Status')

    ad_slug_name = fields.Char('Ad Slug Name')
#     telephone = fields.Char('Telephone Number')
#     company_email = fields.Char('Company Email')
    amount_net = fields.Monetary('Amount in Net', currency_field='company_currency', tracking=True)
    amount_spent = fields.Monetary('Amount Spent', currency_field='company_currency', tracking=True)
    customer_desc = fields.Text('Description of the customer')
    
    ad_headline = fields.Char('Ad Headline')
    ad_content = fields.Char('Ad Content')
    brochure_link = fields.Char('Brochure link')
    ad_call_to_action = fields.Char('Ad Call to action')
    ad_link_url = fields.Char('Ad Link URL')
    ad_image_file = fields.Binary("Ad Image file")

    ad_types = fields.Selection([('header_banner', 'Header banner'), ('leader_board_top', 'Leader board top'),
                               ('leader_board_bottom', 'Leader board bottom'),('login_half_page', 'Login half page')],
                                string='Ad Types')
    ad_plan = fields.Selection([('weekly', 'Weekly'), ('monthly', 'Monthly'),('yearly', 'Yearly')], string='Ad Plan')
    ad_cost_per_view = fields.Char('Ad Cost per View')
    ad_cost_per_click = fields.Char('Ad Cost per click')
    ad_valid_from = fields.Date('Ad Valid From')
    ad_valid_to = fields.Date('Ad Valid To' )
    is_submit = fields.Boolean('Ad Submitted')
    is_ad_live = fields.Boolean('Ad Live')
    bank_name = fields.Char()
    bank_address = fields.Char()
    bank_account_number = fields.Char()
    bank_ifsc_code = fields.Char()

#     is_ad_header_banner = fields.Boolean('Header banner', default=False)
#     is_ad_leader_board_top = fields.Boolean('Leader board top', default=False)
#     is_ad_leader_board_bottom = fields.Boolean('Leader board bottom', default=False)
#     is_ad_login_half_page = fields.Boolean('Login half page', default=False)


    def ad_details_submit(self):
        if self.is_submit == True:
            raise Warning("Ad Details already submitted..!")
        else:
            self.is_submit = True
            self.states = 'submitted'
            ad_verification_obj = self.env["ad.verification"].sudo().create({
                                "name": self.customer,
                                "ad_name": self.name,
                                "ad_type": self.ad_types,
                                "status": 'Submitted',
                                "ad_validfrom": self.ad_valid_from,
                                "ad_validto": self.ad_valid_to,
                                "state":'submitted',
                                "ad_crm_details_id":self.id,
                            })


class ResUsers(models.Model):
    _inherit = "res.users"

#     Default create a customer user.
    @api.model_create_multi
    def create(self, vals_list):
        customer = self.env.ref('pappayalite_crm.pappaya_group_m__team')
        if customer:
            data = vals_list[0]
            if data['groups_id'][0]:
                grp = data['groups_id'][0]
                grp[2].append(customer.id)
        users = super(ResUsers, self).create(vals_list)
        return users


class PappayaAdList(models.Model):
    _name = 'pappaya.ad.list'
    _description = 'Pappaya Ad List'


class PappayaFlights(models.Model):
    _name = 'pappaya.flights'
    _description = 'Pappaya Flights'
    _rec_name = 'flight_name'

    flight_name = fields.Char(string='Flight Name')
    flight_valid_from = fields.Date(string='Flight Valid From')
    flight_valid_to = fields.Date(string='Flight Valid To')
    keywords = fields.Selection([('user_group', 'User Group'), ('city', 'City'), ('state', 'State'), ('district', 'District')])
    keyword_text = fields.Char()

    is_flight_live = fields.Boolean(string='Flight Live')
    amount = field_name = fields.Integer(string='Amount')
    view_cost = fields.Char(string='Cost per View')
    click_cost = fields.Char(string='Cost per Click')
    ad_ids = fields.Many2many('crm.lead', string='Ads')
    ad_id = fields.Many2one('crm.lead', string='Ad')
    flight_status = fields.Char('Flight Status')

class FlightAdsWizard(models.TransientModel):
    _name = 'flight.ads.wizard'

    ad_id = fields.Many2one('crm.lead', string='Ads', required=True)

    def add_flight_ad(self):
        active_id = self.env.context.get('active_id')
        record = self.env['pappaya.flights'].browse(active_id)
        record.ad_id = self.ad_id.id